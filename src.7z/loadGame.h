#pragma once
#include "animEventHandler.h"
#include "onHitEventHandler.h"
#include "actionEventHandler.h"
#include "Utils.h"


namespace loadGame
{
	//static void registerAnimEvents();

	void EventCallBACK(SKSE::MessagingInterface::Message* msg);

};

